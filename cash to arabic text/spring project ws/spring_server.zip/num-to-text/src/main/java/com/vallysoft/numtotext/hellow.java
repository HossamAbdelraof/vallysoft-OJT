package com.vallysoft.numtotext;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class hellow{
	
	@RequestMapping("/hi")
	public Object Hello(@RequestParam(name = "cash", defaultValue = "1") String cash) {
		Map<String, Object> object = new HashMap<>();
		CashCalc CashCals = new CashCalc();
		
		object.put("cash input", cash);
		cash = CashCals.Calculate(cash);
		
		 object.put("text out", cash);
		return object;
	}
	
}